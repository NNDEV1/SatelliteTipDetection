
Satellite-Yolov5 - v2 2021-11-25 11:54pm
==============================

This dataset was exported via roboflow.ai on November 26, 2021 at 5:04 AM GMT

It includes 1447 images.
SatelliteTip are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 2 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Random rotation of between -35 and +35 degrees
* Salt and pepper noise was applied to 12 percent of pixels


